export const MENU_MAX_HEIGHT = 300; // max height for the picker's dropdown menu
export const ROLE_PICKER_WIDTH = 360;
export const ROLE_PICKER_SUBMENU_MIN_WIDTH = 260;
